# SAP PP – Production Order Management

> **A comprehensive study of the SAP Production Planning (SAP PP) module**, covering the complete lifecycle of a Production Order — from creation and release through confirmation and technical completion (TECO).

---

## 📋 Project Overview

This project documents and simulates the **SAP PP Production Order Management** workflow using a custom-built interactive SAP PP Simulator. It covers all key transaction codes used in real-world SAP environments and demonstrates each step with simulator-based screenshots.

| Field | Details |
|---|---|
| **Module** | SAP Production Planning (SAP PP) |
| **Topic** | Production Order Management |
| **Transaction Codes** | CO01, MD16, CO02, CO15 |
| **Submitted by** | Ayush Dwivedi |
| **Roll No** | 23051095 |
| **Report Type** | Project Report – SAP PP Module |

---

## 🗂️ Repository Contents

```
📁 sap-pp-production-order/
├── 📄 README.md                          ← You are here
├── 📄 SAP_PP_Final_Report.docx           ← Full formatted project report (A4, Arial)
├── 🌐 sap_pp_production_order_simulator.html  ← Interactive SAP PP Simulator
└── 📁 screenshots/                       ← Simulator-based step screenshots
    ├── fig3_1_co01_initial.png
    ├── fig3_2_co01_header.png
    ├── fig3_3_co01_release.png
    ├── fig4_1_md16_initial.png
    ├── fig4_2_md16_filter.png
    ├── fig4_3_md16_list.png
    ├── fig5_1_co02_initial.png
    ├── fig5_2_co02_modify.png
    ├── fig6_1_co15_initial.png
    ├── fig6_2_co15_yield.png
    ├── fig6_3_co15_gm.png
    ├── fig7_1_co02_teco_functions.png
    └── fig7_2_co02_teco_status.png
```

---

## 🚀 SAP PP Simulator

The **interactive simulator** (`sap_pp_production_order_simulator.html`) replicates the SAP GUI experience directly in a web browser — no SAP license or installation required.

### How to Run

1. Download `sap_pp_production_order_simulator.html`
2. Open it in any modern browser (Chrome, Firefox, Edge)
3. No dependencies, no install — works fully offline

### Simulator Features

| Transaction | Screen | What You Can Do |
|---|---|---|
| **CO01** | Create Production Order | Enter material, plant, quantity, scheduling; auto-release with BOM/Routing copy |
| **MD16** | Convert Planned Orders | Filter by MRP controller, select and convert planned orders to production orders |
| **CO02** | Change Production Order | Load an order, modify quantity/dates, release, refresh BOM, or apply TECO |
| **CO15** | Confirm Production Order | Enter yield, preview goods movements (Mvt 101 GR + Mvt 261 GI), post confirmation |
| **CO03** | Display Production Order | Read-only view of any order with BOM and goods movement history |
| **COOIS** | Order List / Dashboard | Summary of all orders across statuses with metric cards |

---

## 📖 Transaction Codes Covered

### `CO01` — Create Production Order
Creates a new production order for a material at a specific plant. The system automatically copies the Bill of Materials (BOM) and Routing into the order. Supports auto-release on creation.

### `MD16` — Convert Planned Orders
Displays MRP-generated planned orders filtered by plant and MRP controller. Selected planned orders are permanently converted to production orders and deleted from the MRP list.

### `CO02` — Change Production Order
Used to modify an existing production order — update quantity, change dates, refresh BOM/Routing data, manually release the order, or apply Technical Completion (TECO).

### `CO15` — Confirm Production Order
Posts the actual production quantity against a released order. Simultaneously generates:
- **Goods Receipt** (Movement Type 101) — increases finished goods stock
- **Goods Issue** (Movement Type 261) — reduces component/raw material stock

---

## 📚 Report Chapters

1. Introduction to SAP PP – Production Order
2. Key Concepts and Terminology
3. How to Create and Release a Production Order *(CO01)*
4. How to Create a Production Order by Converting a Planned Order *(MD16)*
5. How to Change a Production Order *(CO02)*
6. How to Confirm a Production Order *(CO15)*
7. How to Technically Complete (TECO) a Production Order
8. Troubleshooting Guide
9. Conclusion

---

## 🔑 Key Concepts

| Term | Definition |
|---|---|
| **BOM** (Bill of Materials) | Structured list of all components required to produce the finished good |
| **Routing** | Sequence of manufacturing operations and work centres |
| **Backflushing** | Automatic goods issue of components during order confirmation (Mvt 261) |
| **Movement Type 101** | Goods Receipt — increases stock of the produced material |
| **Movement Type 261** | Goods Issue — reduces stock of components consumed |
| **TECO** | Technical Completion — closes the order, removes from MRP, deletes reservations |
| **MRP** | Material Requirements Planning — automatically generates planned orders on shortage |

---

## 🖼️ Screenshots

All screenshots were generated from the SAP PP Simulator and mirror real SAP GUI behaviour.

| Figure | Transaction | Description |
|---|---|---|
| 3.1 | CO01 | Production Order Create — Initial Screen |
| 3.2 | CO01 | Order Header with Quantity & Scheduling |
| 3.3 | CO01 | Release Confirmation in Status Bar |
| 4.1 | MD16 | Display Planned Orders — Initial Screen |
| 4.2 | MD16 | Filter by MRP Controller & Plant |
| 4.3 | MD16 | Planned Orders List with Convert Button |
| 5.1 | CO02 | Production Order Change — Initial Screen |
| 5.2 | CO02 | Header with Modified Quantity & Functions Menu |
| 6.1 | CO15 | Enter Production Order Confirmation |
| 6.2 | CO15 | Yield Quantity Entry Screen |
| 6.3 | CO15 | Goods Movements Overview (Mvt 101 & 261) |
| 7.1 | CO02 | Functions Menu — TECO Button Highlighted |
| 7.2 | CO02 | Order Header Showing TECO Status |

---

## 🛠️ Production Order Lifecycle

```
MRP Run
   │
   ▼
Planned Order  ──(MD16)──▶  Production Order Created  ──(CO01/CO02)──▶  RELEASED
                                                                              │
                                                                         (CO15)
                                                                              │
                                                                              ▼
                                                                       CONFIRMED
                                                                              │
                                                                         (CO02)
                                                                              │
                                                                              ▼
                                                                          TECO ✓
```

---

## ⚠️ Troubleshooting

| Issue | Resolution |
|---|---|
| BOM / Routing not copied | Ensure BOM and Routing master data exist for the material before creating the order |
| Order cannot be confirmed | Order must be in **Released** status — use CO02 → Functions → Release |
| Accounting error during GR/GI | Verify the Valuation Class in the Material Master Accounting view |
| Activity price / costing error | Update Standard Cost in the Costing view; run a cost estimate |
| Goods movement failed | Insufficient stock — procure/transfer components then reprocess failed movements |
| Planned order not visible after conversion | It was permanently deleted — search for the resulting Production Order in CO03 |

---

## 📄 Report Format

The project report (`SAP_PP_Final_Report.docx`) follows strict academic formatting:

- **Paper size:** A4
- **Font:** Arial
- **Heading 1:** 16pt, Bold, `#1F3864`
- **Heading 2:** 13pt, Bold, `#2E75B6`
- **Body text:** 11pt, Justified
- **Page numbers:** Bottom right
- **Header:** Report title (right-aligned)
- **Footer:** Author name, Roll No, page number

---

## 👤 Author

**Parth Patel**
Roll No: 2305062

---

*SAP PP – Production Order Management | Project Report*
